from kyt import *
from telethon import events, Button
from kyt.modules import database, harga
import subprocess
import asyncio
import math
import re
import requests
import datetime as DT
import os
import paramiko
# =================================================================
# FUNGSI BACA VAR.TXT (OTOMATIS)
# =================================================================
def get_var_value(key_name):
    """
    Mencari value dari key tertentu di var.txt
    """
    var_path_list = ["/root/var.txt", "/usr/bin/kyt/var.txt"]
    for var_file in var_path_list:
        if os.path.exists(var_file):
            try:
                with open(var_file, "r") as f:
                    lines = f.readlines()
                    for line in lines:
                        if line.startswith(f"{key_name}="):
                            val = line.strip().split("=", 1)[1].replace('"', '').replace("'", "")
                            return val
            except: pass
    return None

# =================================================================
# FUNGSI NOTIFIKASI / TESTIMONI (SUPPORT TOPIC)
# =================================================================
async def kirim_testimoni(user_telegram, role_user, tipe_akun, username_akun, exp_days, quota_str, harga, server_name="SG-DO"):
    """
    Mengirim laporan transaksi ke Group (Support Topic ID format: -100xxx_TopicID)
    """
    try:
        # 1. Ambil ID dari var.txt
        raw_group = get_var_value("GROUP")
        
        if not raw_group: 
            print("⚠️ GROUP ID tidak ditemukan di var.txt")
            return

        # 2. Logika Deteksi Topic (ID_TOPIC)
        # Contoh: -100123456789_45
        target_chat_id = 0
        target_topic_id = None

        if "_" in raw_group:
            parts = raw_group.split("_")
            try:
                target_chat_id = int(parts[0])
                target_topic_id = int(parts[1])
            except ValueError:
                print("❌ Format Group ID salah. Harus angka.")
                return
        else:
            try:
                target_chat_id = int(raw_group)
            except ValueError:
                return

        waktu = DT.datetime.now().strftime("%d/%m/%Y, %H.%M.%S")
        
        # 3. Format Pesan
        pesan = f"""
<b>📢 Account Created</b>
────────────────────
👤 <b>User:</b> {user_telegram}
🏷️ <b>Role:</b> {role_user}
📄 <b>Type:</b> {tipe_akun}
🔥 <b>Username:</b> <code>{username_akun}</code>
📅 <b>Expired:</b> {exp_days} Days
💾 <b>Quota:</b> {quota_str}
💰 <b>Harga:</b> Rp {harga}
🌐 <b>Server:</b> {server_name}
⏰ <b>Time:</b> {waktu}
────────────────────
"""
        # 4. Eksekusi Pengiriman
        if target_topic_id:
            # Kirim ke Spesifik Topic (Menggunakan reply_to untuk Telethon)
            await bot.send_message(target_chat_id, pesan, parse_mode='html', reply_to=target_topic_id)
        else:
            # Kirim ke Group Biasa (Tanpa Topic)
            await bot.send_message(target_chat_id, pesan, parse_mode='html')
        
    except Exception as e:
        print(f"❌ Gagal kirim notif group: {e}")

# =================================================================
# FUNGSI PEMBANTU (HELPER)
# =================================================================

def get_vless_data():
    """Mengambil data user VLESS dari config.json"""
    try:
        cmd = 'grep -E "^#& " "/etc/xray/config.json"'
        raw_output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        data_list = []
        seen_users = set() 
        
        for line in raw_output.splitlines():
            if line.strip():
                parts = line.split()
                if len(parts) >= 3:
                    user = parts[1]
                    exp = parts[2]
                    if user not in seen_users:
                        data_list.append({"user": user, "exp": exp})
                        seen_users.add(user)
        return data_list
    except:
        return []

def render_page_content(data_list, page, mode="list", item_per_page=5):
    total_items = len(data_list)
    total_pages = math.ceil(total_items / item_per_page)
    
    if page < 0: page = 0
    if total_pages > 0 and page >= total_pages: page = total_pages - 1
    if total_pages == 0: page = 0 
    
    start = page * item_per_page
    end = start + item_per_page
    sliced_data = data_list[start:end]
    
    title = "⚡ LIST USER VLESS" if mode == "list" else "🗑️ DELETE USER VLESS"
    msg = f"<b>{title}</b>\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
    
    flat_buttons = [] 
    
    if not sliced_data:
        msg += "<i>⚠️ Tidak ada user VLESS.</i>"
    else:
        for row in sliced_data:
            user = row["user"]
            exp = row["exp"]
            try:
                today = DT.date.today()
                exp_dt = DT.datetime.strptime(exp, "%Y-%m-%d").date()
                diff = (exp_dt - today).days
                if diff >= 0: status = f"🟢 Active ({diff} Hari)"
                else: status = f"🔴 Expired ({abs(diff)} Hari Lalu)"
            except: status = "⚪ Unlimited"

            msg += f"<b>👤 User :</b> <code>{user}</code>\n<b>📅 Exp  :</b> <code>{exp}</code>\n<b>💎 Stat :</b> {status}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n"
            
            if mode == "list":
                flat_buttons.append(Button.inline(f"🔍 {user}", data=f"vlDetail_{user}_{page}"))
            else:
                flat_buttons.append(Button.inline(f"🗑️ {user}", data=f"vlDelExec_{user}_{page}"))

    msg += f"\n📊 <b>Total:</b> {total_items} Users | 📄 <b>Page:</b> {page+1}/{total_pages}"
    grid_buttons = [flat_buttons[i:i + 2] for i in range(0, len(flat_buttons), 2)]
    return msg, total_pages, grid_buttons

# =================================================================
# 1. MENU UTAMA VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'vless'))
async def vless_menu(event):
    sender = await event.get_sender()
    user_id = str(sender.id)
    
    user_balance = database.get_saldo(user_id)
    try: price_vless = harga.daftar_produk['VLESS1']['harga']
    except: price_vless = 0

    try:
        if valid(user_id) != "true":
            return await event.answer("Access Denied", alert=True)
    except: pass

    try:
        try:
            z = requests.get("http://ip-api.com/json/?fields=country,isp", timeout=2).json()
            isp = z.get("isp", "Unknown")
            country = z.get("country", "Unknown")
        except: isp, country = "Unknown", "Unknown"
        
        try: my_domain = DOMAIN
        except: 
            my_domain = get_var_value("DOMAIN") or "Premium Server"

        msg = f"""
<b>⚡ VLESS MANAGER</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>💰 Saldo Anda  :</b> <code>Rp {user_balance:,}</code>
<b>🏷️ Harga Dasar :</b> <code>Rp {price_vless:,}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🟢 Service Status :</b> <code>Active</code>
<b>🌐 Hostname/IP    :</b> <code>{my_domain}</code>
<b>📡 ISP Provider   :</b> <code>{isp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
"""
        inline = [
            [Button.inline("⚡ TRIAL", "trial-vless"), Button.inline("⚡ CREATE (ADMIN)", "create-vless")],
            [Button.inline("📊 LIST USER", "list-vless"), Button.inline("🗑️ DELETE", "delete-vless")],
            [Button.inline("‹ Main Menu ›", "menu")]
        ]
        await event.edit(msg, buttons=inline, parse_mode='html')
    except Exception as e:
        await event.respond(f"Error Menu: {str(e)}")

# =================================================================
# 2. FITUR BELI UNTUK USER (OTOMATIS)
# =================================================================
@bot.on(events.CallbackQuery(pattern=re.compile(b"fix_buy_.*")))
async def buy_vless_handler(event):
    chat = event.chat_id
    user_id = event.sender_id
    sender = await event.get_sender()
    nama_pembeli = sender.first_name
    
    try:
        data_str = event.data.decode('utf-8')
        parts = data_str.split('_', 2) 
        if len(parts) < 3: return
        
        kode_produk = parts[2]

        if kode_produk not in harga.daftar_produk: return 
        produk = harga.daftar_produk[kode_produk]
        
        # FILTER KHUSUS VLESS
        kategori = str(produk.get('service', '')).upper()
        if "VLESS" not in kategori: return

        try:
            biaya = int(str(produk['harga']).replace('.','').replace(',',''))
            durasi = int(produk.get('exp', 30))
            limit_ip = int(produk.get('limit', 2))
            quota = int(produk.get('quota', 0)) 
        except ValueError:
            return await event.answer("❌ Config Harga Error", alert=True)

        saldo_user = database.get_saldo(user_id)
        if saldo_user < biaya:
            kurang = biaya - saldo_user
            msg_kurang = f"❌ SALDO TIDAK CUKUP!\n\n💰 Harga: Rp {biaya:,}\n💳 Saldo: Rp {saldo_user:,}\n📉 Kurang: Rp {kurang:,}\n\nSilakan Topup dulu."
            return await event.answer(msg_kurang, alert=True)

        await event.answer("✅ Saldo Cukup. Memproses...", alert=False)
        await event.delete() 
        
        async with bot.conversation(chat, timeout=60) as conv:
            
            # --- A. MENENTUKAN SERVER DARI KODE PRODUK MENU ---
            if kode_produk == "VLESS_INDO":
                pilihan_server = "srv_pusat"
                nama_server_terpilih = "Server Pusat (INDO)"
            elif kode_produk == "VLESS_SG1":
                pilihan_server = "srv_sg1"
                nama_server_terpilih = "Server SG 1"
            elif kode_produk == "VLESS_SG2":
                pilihan_server = "srv_sg2"
                nama_server_terpilih = "Server SG 2"
            elif kode_produk == "VLESS_SG3":
                pilihan_server = "srv_sg3"
                nama_server_terpilih = "Server SG 3"
            else:
                pilihan_server = "srv_pusat"
                nama_server_terpilih = "Server Pusat"

            # --- B. Input Username ---
            await conv.send_message(f"✅ Anda memilih <b>{nama_server_terpilih}</b>.\n\n<b>👤 Masukkan Username VLESS Baru:</b>\n<i>(Ketik <code>/cancel</code> untuk batal)</i>", parse_mode='html')
            try:
                user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=user_id))
            except asyncio.TimeoutError:
                return await conv.send_message("❌ Waktu habis. Pembelian dibatalkan.", buttons=[[Button.inline("‹ Menu ›", "menu_as_user")]])
                
            if user_msg.raw_text == '/cancel':
                return await conv.send_message("❌ Pembelian Dibatalkan.", buttons=[[Button.inline("‹ Kembali ›", "menu_as_user")]])
            
            username = user_msg.raw_text.strip().replace(" ", "")
            if not username.isalnum():
                 return await conv.send_message("❌ <b>Username Invalid!</b> Gunakan hanya huruf dan angka.", buttons=[[Button.inline("‹ Ulangi ›", "menu_as_user")]], parse_mode='html')

            # --- C. Eksekusi ---
            msg_pro = await conv.send_message(f"🔄 <b>Sedang membuat akun di {nama_server_terpilih}...</b>", parse_mode='html')
            
            # Cek saldo dulu (jangan dipotong dulu agar tidak rugi jika VPS error)
            if database.get_saldo(user_id) >= biaya:
                try:
                    cmd_create = f'printf "%s\\n" "{username}" "{durasi}" "{quota}" "{limit_ip}" | addvless-bot'
                    
                    # =========================================================
                    # LOGIKA PERCABANGAN SERVER
                    # =========================================================
                    if pilihan_server == "srv_pusat":
                        # EKSEKUSI LOKAL
                        raw_out = subprocess.check_output(cmd_create, shell=True).decode("utf-8")
                    else:
                        # EKSEKUSI REMOTE VIA PARAMIKO
                        if pilihan_server == "srv_sg1":
                            remote_ip = "165.245.182.117"
                            remote_pass = "Singgahvpn-18-November"
                        elif pilihan_server == "srv_sg2":
                            remote_ip = "68.183.191.42"
                            remote_pass = "Singgahvpn-11-December"
                        elif pilihan_server == "srv_sg3":
                            remote_ip = "143.198.80.108"
                            remote_pass = "Singgahvpn-02-November"

                        try:
                            ssh_client = paramiko.SSHClient()
                            ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                            ssh_client.connect(hostname=remote_ip, port=22, username="root", password=remote_pass, timeout=15)
                            
                            stdin, stdout, stderr = ssh_client.exec_command(cmd_create)
                            exit_status = stdout.channel.recv_exit_status()
                            raw_out = stdout.read().decode("utf-8").strip()
                            err_log = stderr.read().decode().strip()
                            
                            ssh_client.close()
                            
                            if exit_status != 0 and not raw_out:
                                raise Exception(f"Gagal create di server tujuan. Log: {err_log}")
                                
                        except Exception as remote_error:
                            raise Exception(f"Koneksi/Eksekusi ke {nama_server_terpilih} Gagal: {remote_error}")
                    # =========================================================
                    
                    # Parsing Output dari Script
                    links = [x.group() for x in re.finditer("vless://(.*)", raw_out)]
                    if not links: raise Exception("Gagal mengambil link dari VPS.")
                    
                    link_tls  = links[0].strip()
                    
                    # --- BARU: AMBIL UUID DARI LINK UNTUK DATABASE ---
                    try:
                        # vless://uuid@domain... -> ambil uuid-nya
                        uuid_terbuat = link_tls.replace("vless://", "").split("@")[0]
                    except:
                        uuid_terbuat = "Unknown"

                    # --- POTONG SALDO DENGAN KETERANGAN LENGKAP ---
                    keterangan_db = f"Beli {produk['nama']} | Akun: {username} | UUID: {uuid_terbuat}"
                    database.kurang_saldo(user_id, biaya, keterangan_db)
                    
                    link_tls  = links[0].strip()
                    link_ntls = links[1].strip() if len(links) > 1 else "Not Available"
                    link_grpc = links[2].strip() if len(links) > 2 else "Not Available"
                    
                    try:
                        clean_link = link_tls.replace("vless://", "")
                        uuid = clean_link.split("@")[0]
                        domain = clean_link.split("@")[1].split(":")[0]
                    except:
                        uuid = "Unknown"
                        domain = "Premium Server"
                    
                    sisa_saldo = database.get_saldo(user_id)
                    quota_display = f"{quota} GB" if int(quota) > 0 else "Unlimited"
                    today = DT.date.today()
                    exp_date = today + DT.timedelta(days=int(durasi))
                    today_str = today.strftime("%d/%m/%Y")

                    struk = f"""
<b>✅ PEMBELIAN SUKSES</b>
========================================
 <b>🚀 AKUN VLESS PREMIUM</b>
========================================

 <b>📋 INFORMASI AKUN</b>
 <b>Server   :</b> {nama_server_terpilih}
 <b>👤 Username :</b> <code>{username}</code>
 <b>🌐 Domain   :</b> <code>{domain}</code>
 <b>🔒 Port TLS :</b> <code>443</code>
 <b>🔓 Port None:</b> <code>80</code>
 <b>🔄 Port GRPC:</b> <code>443</code>
 <b>🔑 UUID     :</b> <code>{uuid}</code>
 <b>📡 Network  :</b> <code>WS / GRPC</code>
 <b>🛤️ Path     :</b> <code>/vless</code> / <code>vless-grpc</code>

 <b>🔗 FORMAT KONEKSI</b>
 <b>🔮 TLS:</b>
<code>{link_tls}</code>

 <b>🔮 NON-TLS:</b>
<code>{link_ntls}</code>

 <b>🔮 GRPC:</b>
<code>{link_grpc}</code>

 <b>ℹ️ INFORMASI TAMBAHAN</b>
 <b>💰 Harga    :</b> Rp {biaya:,}
 <b>💳 Sisa     :</b> Rp {sisa_saldo:,}
 <b>📅 Expired  :</b> {exp_date}
 <b>📱 IP Limit :</b> {limit_ip} IP
 <b>💾 Quota    :</b> {quota_display}

========================================
ᵗᵉʳⁱᵐᵃᵏᵃˢⁱʰ ᵗᵉˡᵃʰ ᵐᵉⁿᵍᵍᵘⁿᵃᵏᵃⁿ ˡᵃʸᵃⁿᵃⁿ ᵏᵃᵐⁱ
Generated on {today_str}
========================================
"""
                    await msg_pro.edit(struk, parse_mode='html', link_preview=False, buttons=[[Button.inline("🔙 Menu Utama", "menu")]])
                    
                    # --- NOTIFIKASI KE GROUP ---
                    info_user_tg = f"{nama_pembeli} (<code>{user_id}</code>)"
                    await kirim_testimoni(
                        user_telegram=info_user_tg,
                        role_user="Member/Buyer",
                        tipe_akun="VLESS Premium",
                        username_akun=username,
                        exp_days=durasi,
                        quota_str=quota_display,
                        harga=f"{biaya:,}",
                        server_name=nama_server_terpilih
                    )
                    
                except Exception as e:
                    database.tambah_saldo(user_id, biaya, "REFUND: Gagal System")
                    await msg_pro.edit(f"❌ <b>Gagal System:</b> {str(e)}\nSaldo telah dikembalikan.", parse_mode='html')
            else:
                await msg_pro.edit("❌ <b>Transaksi Gagal:</b> Saldo tidak cukup.", parse_mode='html')

    except Exception as e:
        await event.respond(f"❌ <b>System Error:</b> {str(e)}", parse_mode='html')

# =================================================================
# 3. CREATE VLESS MANUAL (KHUSUS ADMIN)
# =================================================================
@bot.on(events.CallbackQuery(data=b'create-vless'))
async def create_vless_admin(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("❌ Menu ini khusus Admin!", alert=True)
    except: pass

    async def manual_process():
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond('<b>👤 Input Username:</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = res.raw_text.strip()
                
                await event.respond('<b>📅 Input Expired (Hari):</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = res.raw_text.strip()

                await event.respond('<b>💾 Input Quota (GB):</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                quota = res.raw_text.strip()

                await event.respond('<b>📱 Input IP Limit:</b>', parse_mode='html')
                res = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                limit = res.raw_text.strip()
            
            msg_load = await event.respond("Processing...", parse_mode='html')
            cmd = f'printf "%s\n" "{user}" "{exp}" "{quota}" "{limit}" | addvless-bot'
            
            try:
                process = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", process)]
                
                link_tls  = links[0].strip()
                link_ntls = links[1].strip() if len(links) > 1 else "Not Available"
                link_grpc = links[2].strip() if len(links) > 2 else "Not Available"

                try:
                    clean_link = link_tls.replace("vless://", "")
                    uuid = clean_link.split("@")[0]
                    domain = clean_link.split("@")[1].split(":")[0]
                except:
                    uuid = "Unknown"; domain = "Premium Server"

                quota_display = f"{quota} GB" if int(quota) > 0 else "Unlimited"
                today_str = DT.date.today().strftime("%d/%m/%Y")

                struk = f"""
<b>✅ VLESS CREATED (ADMIN)</b>
========================================
 <b>🚀 AKUN VLESS PREMIUM</b>
========================================

 <b>📋 INFORMASI AKUN</b>
 <b>👤 Username :</b> <code>{user}</code>
 <b>🌐 Domain   :</b> <code>{domain}</code>
 <b>🔑 UUID     :</b> <code>{uuid}</code>
 <b>📡 Network  :</b> <code>WS / GRPC</code>

 <b>🔗 FORMAT KONEKSI</b>
 <b>🔮 TLS:</b>
<code>{link_tls}</code>

 <b>🔮 NON-TLS:</b>
<code>{link_ntls}</code>

 <b>🔮 GRPC:</b>
<code>{link_grpc}</code>

 <b>ℹ️ INFORMASI TAMBAHAN</b>
 <b>📅 Expired  :</b> {exp} Hari
 <b>📱 IP Limit :</b> {limit} IP
 <b>💾 Quota    :</b> {quota_display}

========================================
Generated on {today_str}
========================================
"""
                await msg_load.edit(struk, parse_mode='html', buttons=[[Button.inline("Menu", "menu")]])
                
                # --- NOTIFIKASI KE GROUP (ADMIN) ---
                info_user_tg = f"{sender.first_name} (Admin)"
                await kirim_testimoni(
                    user_telegram=info_user_tg,
                    role_user="Admin/Owner",
                    tipe_akun="VLESS Premium",
                    username_akun=user,
                    exp_days=exp,
                    quota_str=quota_display,
                    harga="0 (Created by Admin)",
                    server_name=domain
                )
                # -----------------------------------

            except Exception as e:
                await msg_load.edit(f"❌ Error: {e}")
                
        except asyncio.TimeoutError:
            await event.respond("❌ Waktu Habis.")

    await manual_process()

# =================================================================
# 4. TRIAL VLESS
# =================================================================
@bot.on(events.CallbackQuery(data=b'trial-vless'))
async def trial_vless(event):
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true":
            return await event.answer("Akses Ditolak", alert=True)
    except: pass

    async def trial_vless_process(event):
        try:
            async with bot.conversation(chat, timeout=60) as conv:
                await event.respond("<b>⏱️ Input Durasi Trial (Menit):</b>\n<i>Contoh: 30</i>", parse_mode='html')
                try:
                    resp = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                    exp = resp.raw_text.strip()
                    if not exp.isdigit(): return await event.respond("❌ Angka saja.")
                except: return await event.respond("❌ Timeout")

            msg_load = await event.respond("Creating...", parse_mode='html')
            cmd = f'printf "%s\n" "{exp}" | bot-trialvless'
            try:
                a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                links = [x.group() for x in re.finditer("vless://(.*)", a)]
                
                try: remarks = links[0].split("#")[-1]
                except: remarks = "Trial"

                await msg_load.edit(f"""
<b>✅ TRIAL SUKSES</b>
<b>User:</b> {remarks}
<b>Exp:</b> {exp} Menit
<b>Link:</b> <code>{links[0]}</code>
""", parse_mode='html', buttons=[[Button.inline("Menu", "menu")]])
            except: 
                await msg_load.edit("❌ Gagal.")
        except Exception as e:
            await event.respond(f"Error: {e}")

    await trial_vless_process(event)

# =================================================================
# 5. LIST & DELETE HANDLER
# =================================================================
@bot.on(events.CallbackQuery(data=b'list-vless'))
async def list_vless_handler(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass

    data_list = get_vless_data()
    msg, total_pages, user_buttons = render_page_content(data_list, 0, mode="list")
    
    nav_buttons = []
    if total_pages > 1:
        nav_buttons.append(Button.inline("Next ⏩", data=f"vlPage_1"))
    
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlPage_(\d+)"))
async def paginate_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, user_buttons = render_page_content(data_list, page, mode="list")
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlPage_{page+1}"))
    all_buttons = user_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"vlDetail_(.+)_(.+)"))
async def detail_vless(event):
    try:
        user = event.pattern_match.group(1).decode()
        page_origin = event.pattern_match.group(2).decode()
    except: return
    try: msg_wait = await event.edit("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    except: msg_wait = await event.respond("<b>🔄 Mengambil Detail...</b>", parse_mode='html')
    try:
        cmd_path = '/usr/bin/kyt/shell/bot/bot-vless-detail' 
        if not os.path.exists(cmd_path): return await msg_wait.edit(f"❌ Script {cmd_path} tidak ditemukan.")
        subprocess.run(f"chmod +x {cmd_path}", shell=True)
        cmd = f'{cmd_path} "{user}"'
        process = subprocess.run(cmd, shell=True, check=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        raw_data = process.stdout.decode("utf-8").strip()
        
        if not raw_data or "Error" in raw_data:
            await msg_wait.edit(f"❌ <b>Gagal:</b> User {user} tidak ditemukan.", buttons=[[Button.inline("‹ Kembali ›", data=f"vlPage_{page_origin}")]])
            return

        parts = raw_data.split('|')
        d_user = parts[0]
        d_domain = parts[1]
        d_uuid = parts[2]
        d_exp = parts[3]
        d_quota = parts[4]
        d_ip = parts[5]
        d_tls = parts[6]
        
        msg = f"""
<b>👤 USER DETAILS: {d_user}</b>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🌐 Domain    :</b> <code>{d_domain}</code>
<b>💾 Quota     :</b> <code>{d_quota}</code>
<b>📱 IP Limit  :</b> <code>{d_ip}</code>
<b>📅 Expired   :</b> <code>{d_exp}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔑 KEY CONFIGURATION</b>
<b>🆔 UUID      :</b> <code>{d_uuid}</code>
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
<b>🔗 LINK TLS:</b>
<code>{d_tls}</code>
"""
        buttons = [[Button.inline("‹ Kembali ke List ›", data=f"vlPage_{page_origin}")]]
        await msg_wait.edit(msg, buttons=buttons, parse_mode='html', link_preview=False)
    except Exception as e:
        await msg_wait.edit(f"<b>❌ Error:</b> {str(e)}", parse_mode='html')

@bot.on(events.CallbackQuery(data=b'delete-vless'))
async def delete_vless(event):
    sender = await event.get_sender()
    try:
        if valid(str(sender.id)) != "true": return
    except: pass
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, 0, mode="delete")
    nav_buttons = []
    if total_pages > 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_1"))
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.reply(msg, buttons=all_buttons, parse_mode='html')

@bot.on(events.CallbackQuery(pattern=b"vlDelPage_(\d+)"))
async def paginate_delete_vless(event):
    try: page = int(event.pattern_match.group(1).decode())
    except: page = 0
    data_list = get_vless_data()
    msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
    nav_buttons = []
    if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlDelPage_{page-1}"))
    if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_{page+1}"))
    all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
    try: await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except: await event.answer("Halaman tidak berubah")

@bot.on(events.CallbackQuery(pattern=b"vlDelExec_(.+)_(.+)"))
async def delete_vless_exec(event):
    try:
        user = event.pattern_match.group(1).decode()
        page = int(event.pattern_match.group(2).decode())
    except: return
    await event.answer(f"⏳ Menghapus user: {user}...", alert=False)
    cmd = f'printf "%s\n" "{user}" | bot-delvless' 
    try:
        subprocess.check_output(cmd, shell=True)
        await event.answer(f"✅ User {user} Berhasil Dihapus!", alert=True)
        data_list = get_vless_data()
        msg, total_pages, del_buttons = render_page_content(data_list, page, mode="delete")
        nav_buttons = []
        if page > 0: nav_buttons.append(Button.inline("⏪ Prev", data=f"vlDelPage_{page-1}"))
        if page < total_pages - 1: nav_buttons.append(Button.inline("Next ⏩", data=f"vlDelPage_{page+1}"))
        all_buttons = del_buttons + [nav_buttons] + [[Button.inline("‹ Kembali ›", "vless")]]
        await event.edit(msg, buttons=all_buttons, parse_mode='html')
    except Exception as e:
        await event.answer(f"❌ Gagal menghapus: {str(e)}", alert=True)