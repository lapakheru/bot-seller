# FILE: /usr/bin/kyt/modules/config.py

# =================================================================
# 🔐 CONFIGURATION FILE
# Simpan semua data sensitif di sini. Jangan disebar!
# =================================================================

# 1. TELEGRAM ADMIN CONFIG
# ID Telegram Owner (Angka) - Ganti dengan ID Anda
OWNER_ID = "1469244768"

# 2. RAMA SHOP H2H API KEY
RAMASHOP_KEY = "rg_4e4fe8752f443e75f695db560adaa6"

# 3. GLOBAL DOMAIN (Opsional, jika ingin setting manual)
# Jika dikosongkan, script akan mencoba deteksi otomatis atau pakai default
DOMAIN_MANUAL = "id1.borneossh.my.id"
